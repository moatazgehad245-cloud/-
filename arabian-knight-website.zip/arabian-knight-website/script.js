const loader = document.getElementById('loader');
window.addEventListener('load', () => setTimeout(() => loader.classList.add('hide'), 650));

const menuToggle = document.getElementById('menuToggle');
const nav = document.getElementById('mainNav');
menuToggle?.addEventListener('click', () => nav.classList.toggle('open'));
nav?.querySelectorAll('a').forEach(a => a.addEventListener('click', () => nav.classList.remove('open')));

const quoteForm = document.getElementById('quoteForm');
quoteForm?.addEventListener('submit', (event) => {
  event.preventDefault();
  const data = new FormData(quoteForm);
  const message = [
    'طلب عرض سعر جديد — الفارس العربي',
    `الاسم: ${data.get('name')}`,
    `واتساب: ${data.get('phone')}`,
    `عرض النافذة: ${data.get('width')} سم`,
    `ارتفاع النافذة: ${data.get('height')} سم`,
    `النوع: ${data.get('type')}`,
    `المدينة: ${data.get('city') || 'غير محددة'}`
  ].join('\n');
  // Replace this demo number with the store's real WhatsApp number.
  const whatsappNumber = '201000000000';
  window.open(`https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`, '_blank', 'noopener');
});

async function initHorse() {
  const canvas = document.getElementById('horseCanvas');
  if (!canvas) return;
  try {
    const THREE = await import('three');
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(34, 1, 0.1, 100);
    camera.position.set(0, 1.4, 8.8);
    const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;

    scene.add(new THREE.HemisphereLight(0xffe8c1, 0x684728, 2.1));
    const key = new THREE.DirectionalLight(0xffe1ad, 3.1);
    key.position.set(-3, 7, 5); scene.add(key);
    const rim = new THREE.DirectionalLight(0xffc36b, 2.2);
    rim.position.set(4, 3, -4); scene.add(rim);

    const horse = new THREE.Group(); scene.add(horse);
    const coat = new THREE.MeshStandardMaterial({ color: 0x38271f, roughness: .48, metalness: .03 });
    const highlight = new THREE.MeshStandardMaterial({ color: 0x65432d, roughness: .4 });
    const dark = new THREE.MeshStandardMaterial({ color: 0x211813, roughness: .65 });
    const maneMat = new THREE.MeshStandardMaterial({ color: 0x17120f, roughness: .8 });
    const gold = new THREE.MeshStandardMaterial({ color: 0xc69b57, metalness: .65, roughness: .28 });

    function ellipsoid(parent, material, pos, scale, rot={x:0,y:0,z:0}) {
      const mesh = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 18), material);
      mesh.position.set(...pos); mesh.scale.set(...scale); mesh.rotation.set(rot.x,rot.y,rot.z); parent.add(mesh); return mesh;
    }
    function link(parent, material, a, b, radiusA, radiusB) {
      const start = new THREE.Vector3(...a), end = new THREE.Vector3(...b);
      const dir = new THREE.Vector3().subVectors(end,start);
      const mesh = new THREE.Mesh(new THREE.CylinderGeometry(radiusB,radiusA,dir.length(),14), material);
      mesh.position.copy(start).add(end).multiplyScalar(.5);
      mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),dir.normalize());
      parent.add(mesh); return mesh;
    }

    // Stylized sculptural Arabian horse assembled from articulated forms.
    ellipsoid(horse, coat, [0,.05,0], [1.55,.66,.52], {z:-.04}); // barrel
    ellipsoid(horse, highlight, [-1.05,.28,0], [.62,.72,.55], {z:-.25}); // hindquarter
    ellipsoid(horse, coat, [1.05,.43,0], [.66,.88,.53], {z:-.35}); // chest
    // Arched neck
    link(horse, coat, [.82,.65,0], [1.62,2.0,0], .42,.24);
    ellipsoid(horse, highlight, [1.32,1.38,0], [.38,.73,.34], {z:-.43});
    // Refined head and muzzle
    link(horse, coat, [1.58,1.85,0], [2.08,2.43,0], .24,.16);
    ellipsoid(horse, highlight, [2.12,2.43,0], [.28,.35,.22], {z:-.35});
    ellipsoid(horse, coat, [2.31,2.27,0], [.25,.13,.17], {z:-.15});
    ellipsoid(horse, dark, [2.48,2.29,0], [.10,.075,.12]);
    // Ears
    link(horse, coat, [1.98,2.64,-.12], [1.92,3.05,-.13], .10,.025);
    link(horse, coat, [2.14,2.64,.12], [2.29,3.02,.12], .10,.025);
    // Eye visible on near side
    ellipsoid(horse, gold, [2.08,2.53,.205], [.075,.075,.035]);
    ellipsoid(horse, dark, [2.09,2.53,.235], [.027,.04,.015]);
    // Mane flowing along neck
    for(let i=0;i<9;i++){
      const t=i/8;
      const x=.91+t*.92, y=1.05+t*1.25;
      link(horse,maneMat,[x,y+.18,-.04],[x-.25,y-.13,-.06],.095,.018);
    }
    // Tail
    link(horse,maneMat,[-1.55,.4,0],[-2.02,.05,0],.16,.09);
    link(horse,maneMat,[-2.02,.05,0],[-2.35,-.35,.02],.09,.012);

    const legs=[];
    const legSpecs=[
      {x:-1.05,z:.32,front:false,phase:0},
      {x:-.78,z:-.32,front:false,phase:Math.PI},
      {x:1.1,z:.32,front:true,phase:Math.PI},
      {x:1.32,z:-.32,front:true,phase:0}
    ];
    legSpecs.forEach((spec)=>{
      const pivot=new THREE.Group(); pivot.position.set(spec.x,-.28,spec.z); horse.add(pivot);
      const upperLen=spec.front?.78:.72, lowerLen=spec.front?.76:.72;
      link(pivot,coat,[0,0,0],[spec.front?-.10:.12,-upperLen,0],.17,.105);
      const kneeY=-upperLen;
      ellipsoid(pivot,highlight,[spec.front?-.10:.12,kneeY,0],[.12,.13,.12]);
      link(pivot,coat,[spec.front?-.10:.12,kneeY,0],[spec.front?.03:-.08,kneeY-lowerLen,0],.09,.055);
      ellipsoid(pivot,dark,[spec.front?.03:-.08,kneeY-lowerLen-.04,0],[.13,.09,.14]);
      legs.push({pivot,phase:spec.phase});
    });

    horse.position.set(-.25,-.8,0);
    horse.rotation.y=-.12;
    const groundShadow = new THREE.Mesh(new THREE.CircleGeometry(2.35,48), new THREE.MeshBasicMaterial({color:0x4d3824,transparent:true,opacity:.18}));
    groundShadow.rotation.x=-Math.PI/2; groundShadow.position.set(0,-.81,-.3); scene.add(groundShadow);

    const dustGroup=new THREE.Group(); scene.add(dustGroup);
    const dustGeo=new THREE.BufferGeometry(), dustCount=90, positions=new Float32Array(dustCount*3);
    for(let i=0;i<dustCount;i++){positions[i*3]=(Math.random()-.5)*6;positions[i*3+1]=Math.random()*2-1;positions[i*3+2]=(Math.random()-.5)*2;}
    dustGeo.setAttribute('position',new THREE.BufferAttribute(positions,3));
    const dust=new THREE.Points(dustGeo,new THREE.PointsMaterial({color:0xf5d99f,size:.035,transparent:true,opacity:.55})); dustGroup.add(dust);

    let targetX=0,targetY=0;
    window.addEventListener('pointermove',e=>{targetX=(e.clientX/window.innerWidth-.5)*.22;targetY=(e.clientY/window.innerHeight-.5)*.12;},{passive:true});
    const resize=()=>{
      const w=canvas.clientWidth||canvas.parentElement.clientWidth;
      const h=canvas.clientHeight||canvas.parentElement.clientHeight;
      renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();
    };
    new ResizeObserver(resize).observe(canvas.parentElement); resize();
    const clock=new THREE.Clock();
    function animate(){
      requestAnimationFrame(animate);
      const t=clock.getElapsedTime();
      horse.rotation.y += (targetX-horse.rotation.y)*.018;
      horse.rotation.x += (-targetY-horse.rotation.x)*.018;
      horse.position.y=-.8+Math.sin(t*1.7)*.035;
      legs.forEach((leg,i)=>{leg.pivot.rotation.x=Math.sin(t*2.1+leg.phase)*.10;});
      dust.rotation.y=t*.025;
      renderer.render(scene,camera);
    }
    animate();
  } catch (error) {
    console.warn('3D scene could not be initialized. Check internet access for Three.js.', error);
    canvas.style.display='none';
  }
}
initHorse();
